var msg = document.currentScript.dataset.data;
$.notify(msg, {status: 'error'});